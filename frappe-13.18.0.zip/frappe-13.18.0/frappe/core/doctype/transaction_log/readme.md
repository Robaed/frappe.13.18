# Transaction Log Changelog

## v1.0.0
Initial version

The line hash summarizes:
- The index of the row
- The timestamp
- The document raw data

The chain hash summarizes:
- The previous line hash
- The current line hash

## v1.0.1
Modification of the timestamp fieldtype from "Time" to "Datetime"